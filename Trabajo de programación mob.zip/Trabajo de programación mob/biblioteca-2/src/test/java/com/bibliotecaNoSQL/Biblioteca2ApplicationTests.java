package com.bibliotecaNoSQL;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Biblioteca2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
